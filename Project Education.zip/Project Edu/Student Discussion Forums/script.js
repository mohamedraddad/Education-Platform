// Wait for the DOM content to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get references to the post composer elements
    const postTextarea = document.querySelector('.post-composer textarea');
    const postButton = document.getElementById('post-btn');
    const forumPosts = document.querySelector('.forum-posts');
    
    // Get reference to new topic button
    const newTopicBtn = document.getElementById('new-topic-btn');
    
    // Initialize post category (default)
    let currentCategory = 'General Discussion';
    
    // Event listener for post button
    postButton.addEventListener('click', function() {
        const postContent = postTextarea.value.trim();
        
        // Check if the post content is not empty
        if (postContent) {
            // Create and publish the post
            publishPost(postContent, currentCategory);
            
            // Clear the textarea
            postTextarea.value = '';
        } else {
            alert('Please enter some content for your post');
        }
    });
    
    // Event listener for Enter key in textarea (Ctrl+Enter to submit)
    postTextarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            postButton.click();
        }
    });
    
    // Event listener for "Start New Topic" button - create modal
    newTopicBtn.addEventListener('click', function() {
        showNewTopicModal();
    });
    
    // Function to publish a new post
    function publishPost(content, category) {
        // Create the post element
        const postElement = document.createElement('div');
        postElement.className = 'post';
        
        // Get current user's initial (can be replaced with actual user data)
        const userInitial = getUserInitial();
        
        // Get current time
        const timePosted = 'Just now';
        
        // Create post HTML structure
        postElement.innerHTML = `
            <div class="post-header">
                <div class="post-author">
                    <div class="author-avatar">${userInitial}</div>
                    <div class="author-info">
                        <div class="author-name">${getCurrentUsername()}</div>
                        <div class="post-time">${timePosted}</div>
                    </div>
                </div>
                <div class="post-category">${category}</div>
            </div>
            <div class="post-content">
                <p>${content}</p>
            </div>
            <div class="post-footer">
                <div class="post-stats">
                    <div class="post-stat">
                        <i class="far fa-comment"></i>
                        <span>0</span>
                    </div>
                    <div class="post-stat">
                        <i class="far fa-thumbs-up"></i>
                        <span>0</span>
                    </div>
                    <div class="post-stat">
                        <i class="far fa-eye"></i>
                        <span>1</span>
                    </div>
                </div>
                <div class="post-actions">
                    <div class="post-action">
                        <i class="far fa-bookmark"></i>
                    </div>
                    <div class="post-action">
                        <i class="fas fa-share-alt"></i>
                    </div>
                </div>
            </div>
        `;
        
        // Add interaction to the new post
        addPostInteractions(postElement);
        
        // Insert the new post at the beginning of the posts list
        forumPosts.insertBefore(postElement, forumPosts.firstChild);
        
        // Add animation effect to the new post
        postElement.style.animation = 'none';
        setTimeout(() => {
            postElement.style.animation = 'fadeIn 0.5s ease-out';
        }, 10);
    }
    
    // Function to create and show the new topic modal
    function showNewTopicModal() {
        // Check if modal already exists
        let modal = document.querySelector('.modal');
        
        if (!modal) {
            // Create modal if it doesn't exist
            modal = document.createElement('div');
            modal.className = 'modal';
            
            // Create modal content
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Create New Topic</h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-label" for="topic-title">Topic Title</label>
                            <input type="text" id="topic-title" class="form-input" placeholder="Enter a descriptive title">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="topic-category">Category</label>
                            <select id="topic-category" class="form-select">
                                <option value="General Discussion">General Discussion</option>
                                <option value="SQL and Databases">SQL and Databases</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Data Science">Data Science</option>
                                <option value="ML">ML</option>
                                <option value="AI">AI</option>
                                <option value="Literature">Literature</option>
                                <option value="Study Group">Study Group</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="topic-content">Content</label>
                            <textarea id="topic-content" class="form-input" rows="5" placeholder="Describe your topic or ask your question"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="cancel-topic">Cancel</button>
                        <button class="btn" id="publish-topic">Publish Topic</button>
                    </div>
                </div>
            `;
            
            // Add modal to body
            document.body.appendChild(modal);
            
            // Show modal
            setTimeout(() => {
                modal.style.display = 'flex';
            }, 10);
            
            // Event listener for close button
            const closeBtn = modal.querySelector('.modal-close');
            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
            
            // Event listener for cancel button
            const cancelBtn = modal.querySelector('#cancel-topic');
            cancelBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
            
            // Event listener for publish button
            const publishBtn = modal.querySelector('#publish-topic');
            publishBtn.addEventListener('click', () => {
                const title = modal.querySelector('#topic-title').value.trim();
                const category = modal.querySelector('#topic-category').value;
                const content = modal.querySelector('#topic-content').value.trim();
                
                if (title && content) {
                    // Update current category
                    currentCategory = category;
                    
                    // Publish the topic
                    publishPost(content, category);
                    
                    // Close the modal
                    modal.style.display = 'none';
                } else {
                    alert('Please fill in both title and content');
                }
            });
            
            // Close modal when clicking outside
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        } else {
            // Just show the existing modal
            modal.style.display = 'flex';
        }
    }
    
    // Function to add interactions to posts (likes, comments, etc.)
    function addPostInteractions(postElement) {
        // Like functionality
        const likeBtn = postElement.querySelector('.fa-thumbs-up').parentElement;
        const likeCount = likeBtn.querySelector('span');
        
        likeBtn.addEventListener('click', function() {
            const currentLikes = parseInt(likeCount.textContent);
            const icon = likeBtn.querySelector('i');
            
            if (icon.classList.contains('far')) {
                // Like the post
                likeCount.textContent = currentLikes + 1;
                icon.classList.remove('far');
                icon.classList.add('fas');
                icon.style.color = 'var(--primary)';
            } else {
                // Unlike the post
                likeCount.textContent = currentLikes - 1;
                icon.classList.remove('fas');
                icon.classList.add('far');
                icon.style.color = '';
            }
        });
        
        // Bookmark functionality
        const bookmarkBtn = postElement.querySelector('.fa-bookmark').parentElement;
        
        bookmarkBtn.addEventListener('click', function() {
            const icon = bookmarkBtn.querySelector('i');
            
            if (icon.classList.contains('far')) {
                // Bookmark the post
                icon.classList.remove('far');
                icon.classList.add('fas');
                icon.style.color = 'var(--primary)';
            } else {
                // Remove bookmark
                icon.classList.remove('fas');
                icon.classList.add('far');
                icon.style.color = '';
            }
        });
    }
    
    // Add interactions to existing posts
    document.querySelectorAll('.post').forEach(post => {
        addPostInteractions(post);
    });
    
    // Helper function to get current user's initial (placeholder)
    function getUserInitial() {
        // This should be replaced with actual user data
        // For now, return a random initial for demonstration
        const initials = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K'];
        return initials[Math.floor(Math.random() * initials.length)];
    }
    
    // Helper function to get current username (placeholder)
    function getCurrentUsername() {
        // This should be replaced with actual user data
        // For now, return a placeholder name
        return 'Current User';
    }
});