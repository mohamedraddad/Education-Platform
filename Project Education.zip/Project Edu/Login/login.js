document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
  
    // Password visibility toggle
    togglePasswordButtons.forEach(button => {
      button.addEventListener('click', () => {
        const input = button.previousElementSibling;
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        
        // Update icon
        const svg = button.querySelector('svg');
        if (type === 'password') {
          svg.innerHTML = '<path d="M12 5c-7.333 0-12 6-12 6s4.667 6 12 6 12-6 12-6-4.667-6-12-6Z"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>';
        } else {
          svg.innerHTML = '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7.33 0 12 6 12 6a13.16 13.16 0 0 1-1.67 1.67"/><path d="M6.61 6.61A13.526 13.526 0 0 0 0 11s4.67 6 12 6c2.3 0 4.61-.5 6.61-1.61"/><line x1="2" y1="2" x2="22" y2="22"/>';
        }
      });
    });
  
    // Password strength indicator
    const signupPassword = document.getElementById('signupPassword');
    const strengthBars = document.querySelectorAll('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
  
    const calculatePasswordStrength = (password) => {
      if (!password) return 0;
      
      let score = 0;
      
      // Length check
      if (password.length >= 8) score += 1;
      if (password.length >= 12) score += 1;
      
      // Complexity checks
      if (/[A-Z]/.test(password)) score += 1;
      if (/[a-z]/.test(password)) score += 1;
      if (/[0-9]/.test(password)) score += 1;
      if (/[^A-Za-z0-9]/.test(password)) score += 1;
      
      return Math.min(5, score);
    };
  
    const updatePasswordStrength = (password) => {
      const strength = calculatePasswordStrength(password);
      const messages = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
      const colors = ['#ef4444', '#ef4444', '#f59e0b', '#22c55e', '#22c55e', '#22c55e'];
      
      strengthBars.forEach((bar, index) => {
        if (index < strength) {
          bar.style.backgroundColor = colors[strength];
          bar.classList.add('active');
        } else {
          bar.style.backgroundColor = '';
          bar.classList.remove('active');
        }
      });
      
      strengthText.textContent = messages[strength];
      strengthText.style.color = colors[strength];
    };
  
    if (signupPassword) {
      signupPassword.addEventListener('input', (e) => {
        updatePasswordStrength(e.target.value);
      });
    }
  
    // Form validation
    const validateEmail = (email) => {
      return /\S+@\S+\.\S+/.test(email);
    };
  
    const validatePassword = (password) => {
      return password.length >= 8;
    };
  
    const showError = (input, message) => {
      const errorElement = input.parentElement.parentElement.querySelector('.error-message');
      errorElement.textContent = message;
      input.classList.add('error');
    };
  
    const clearError = (input) => {
      const errorElement = input.parentElement.parentElement.querySelector('.error-message');
      errorElement.textContent = '';
      input.classList.remove('error');
    };
  
    // Login form submission
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email');
        const password = document.getElementById('password');
        const rememberMe = document.getElementById('rememberMe');
        let isValid = true;
  
        // Clear previous errors
        clearError(email);
        clearError(password);
  
        // Validate email
        if (!email.value) {
          showError(email, 'Email is required');
          isValid = false;
        } else if (!validateEmail(email.value)) {
          showError(email, 'Please enter a valid email');
          isValid = false;
        }
  
        // Validate password
        if (!password.value) {
          showError(password, 'Password is required');
          isValid = false;
        }
  
        if (isValid) {
          const submitButton = loginForm.querySelector('button[type="submit"]');
          const buttonText = submitButton.querySelector('.btn-text');
          const buttonLoader = submitButton.querySelector('.btn-loader');
  
          // Show loading state
          submitButton.disabled = true;
          buttonText.style.opacity = '0';
          buttonLoader.style.display = 'block';
  
          try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            console.log('Login:', { 
              email: email.value, 
              password: password.value,
              rememberMe: rememberMe.checked 
            });
            // Redirect would happen here
          } catch (error) {
            console.error('Login failed:', error);
          } finally {
            // Reset button state
            submitButton.disabled = false;
            buttonText.style.opacity = '1';
            buttonLoader.style.display = 'none';
          }
        }
      });
    }
  
    // Signup form submission
    if (signupForm) {
      signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const fullName = document.getElementById('fullName');
        const email = document.getElementById('signupEmail');
        const password = document.getElementById('signupPassword');
        const agreeTerms = document.getElementById('agreeTerms');
        let isValid = true;
  
        // Clear previous errors
        clearError(fullName);
        clearError(email);
        clearError(password);
        
        // Validate full name
        if (!fullName.value.trim()) {
          showError(fullName, 'Full name is required');
          isValid = false;
        }
  
        // Validate email
        if (!email.value) {
          showError(email, 'Email is required');
          isValid = false;
        } else if (!validateEmail(email.value)) {
          showError(email, 'Please enter a valid email');
          isValid = false;
        }
  
        // Validate password
        if (!password.value) {
          showError(password, 'Password is required');
          isValid = false;
        } else if (!validatePassword(password.value)) {
          showError(password, 'Password must be at least 8 characters');
          isValid = false;
        }
  
        // Validate terms
        if (!agreeTerms.checked) {
          const errorElement = agreeTerms.parentElement.nextElementSibling;
          errorElement.textContent = 'You must agree to the terms';
          isValid = false;
        }
  
        if (isValid) {
          const submitButton = signupForm.querySelector('button[type="submit"]');
          const buttonText = submitButton.querySelector('.btn-text');
          const buttonLoader = submitButton.querySelector('.btn-loader');
  
          // Show loading state
          submitButton.disabled = true;
          buttonText.style.opacity = '0';
          buttonLoader.style.display = 'block';
  
          try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            console.log('Signup:', {
              fullName: fullName.value,
              email: email.value,
              password: password.value,
              agreeTerms: agreeTerms.checked
            });
            // Redirect would happen here
          } catch (error) {
            console.error('Signup failed:', error);
          } finally {
            // Reset button state
            submitButton.disabled = false;
            buttonText.style.opacity = '1';
            buttonLoader.style.display = 'none';
          }
        }
      });
    }
  });
  
  // Page switching
  function switchPage(page) {
    const loginPage = document.getElementById('loginPage');
    const signupPage = document.getElementById('signupPage');
    
    if (page === 'signup') {
      loginPage.classList.add('hidden');
      signupPage.classList.remove('hidden');
      history.pushState(null, '', '/signup');
    } else {
      signupPage.classList.add('hidden');
      loginPage.classList.remove('hidden');
      history.pushState(null, '', '/login');
    }
  }
  
  // Social login handler
  function handleSocialLogin(provider) {
    console.log(`Login with ${provider}`);
    // Social login implementation would go here
  }
  