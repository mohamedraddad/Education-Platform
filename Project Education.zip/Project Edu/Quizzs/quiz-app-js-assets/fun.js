const configContainer = document.querySelector(".config-container");
const answerOptions = document.querySelector(".answer-options");
const quizContainer = document.querySelector(".quiz-container");
const nextQuestionBtn = document.querySelector(".next-question-btn");
const questionStatus = document.querySelector(".question-status");
const timerDisplay = document.querySelector(".timer-duration");
const resultContainer = document.querySelector(".result-container");

const QUIZ_TIME_LIMIT = 10;
let currentTime = QUIZ_TIME_LIMIT;
let timer = null;
let quizCategory = "Programming";   
let numberOfQuestions = 5;
let currentQuestion = null;
const questionsIndexHistory = [];
let correctAnswerCount = 0;

// Display the quiz result and hide the quiz container
const showQuizResult = () => {
    quizContainer.style.display = "none";
    resultContainer.style.display = "block";
    const resultText = `You answered <b>${correctAnswerCount}</b> out of <b>${numberOfQuestions}</b> questions correctly. Great effort!`;
    document.querySelector(".result-massage").innerHTML = resultText;
}

// Clear and reset timer 
const resetTimer = () => {
   clearInterval(timer);
   currentTime = QUIZ_TIME_LIMIT;
   timerDisplay.textContent = `${currentTime}s`;
}

// Initialize and start the timer for the current question
const startTimer = () => {
    resetTimer();
    timer = setInterval(() => {
      currentTime--;
      timerDisplay.textContent = `${currentTime}s`;
  
      if (currentTime <= 0) {
        clearInterval(timer);
        // Auto-select incorrect when time runs out
        highlightCorrectAnswer();
        quizContainer.querySelector(".quiz-timer").style.background = "#c31402";
        // Disable all answer options after time is up
        answerOptions.querySelectorAll(".answer-option").forEach(option => option.style.pointerEvents = "none");
        nextQuestionBtn.style.visibility = "visible";
        nextQuestionBtn.disabled = false;
      }
    }, 1000);
};

// Fetch random question from selected category  
const getRandomQuestions = () => {
    const categoryQuestions = questions.find(cat => 
        cat.category.toLowerCase() === quizCategory.toLowerCase()
    )?.questions || [];
    
    // Show the result if all questions have been used
    if (questionsIndexHistory.length >= Math.min(categoryQuestions.length, numberOfQuestions)) {
        showQuizResult();
        return null;
    }
    
    // Filter out already asked questions and choose a random one
    const availableQuestions = categoryQuestions.filter((_, index) => !questionsIndexHistory.includes(index));
    
    if (availableQuestions.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * availableQuestions.length);
    const randomQuestion = availableQuestions[randomIndex];
    
    // Find the index of the random question in the original array
    const originalIndex = categoryQuestions.findIndex(q => q === randomQuestion);
    questionsIndexHistory.push(originalIndex);
    
    return randomQuestion;
}

// Highlight the Correct Answer option and icon
const highlightCorrectAnswer = () => {
    const correctOption = answerOptions.querySelectorAll(".answer-option")[currentQuestion.correctAnswer];
    correctOption.classList.add("correct");
    const iconHtml = `<span class="material-symbols-rounded">check_circle</span>`;
    correctOption.insertAdjacentHTML("beforeend", iconHtml);
}

// Handle the user answer selection
const handleAnswer = (option, answerIndex) => {
    clearInterval(timer);
    const isCorrect = currentQuestion.correctAnswer === answerIndex;
    option.classList.add(isCorrect ? 'correct' : 'incorrect');
    
    if (!isCorrect) {
        highlightCorrectAnswer();
    } else {
        correctAnswerCount++;
    }
    
    // Insert icon based on correctness
    const iconHtml = `<span class="material-symbols-rounded">${isCorrect ? 'check_circle' : 'cancel'}</span>`;
    option.insertAdjacentHTML("beforeend", iconHtml);
    
    // Disable all answer options after one option is selected
    answerOptions.querySelectorAll(".answer-option").forEach(option => option.style.pointerEvents = "none");
    nextQuestionBtn.style.visibility = "visible";
    // Enable the next button after answering
    nextQuestionBtn.disabled = false;
}

// Render the current question and its options in the quiz
const renderQuestion = () => {
    currentQuestion = getRandomQuestions();
    if (!currentQuestion) {
        clearInterval(timer);
        questionStatus.innerHTML = `<b>Quiz completed!</b>`;
        return;
    }
    
    // UPDATE THE UI
    answerOptions.innerHTML = "";
    nextQuestionBtn.style.visibility = "hidden";
    quizContainer.querySelector(".quiz-timer").style.background = "#32313C";
    document.querySelector(".question-text").textContent = currentQuestion.question;
    questionStatus.innerHTML = `<b>${questionsIndexHistory.length}</b> of <b>${numberOfQuestions}</b> <b>Questions</b>`;
    // Reset next button state
    nextQuestionBtn.disabled = true;
    
    // Create option <li> elements and append them, and add click event listeners
    currentQuestion.options.forEach((option, index) => {
        const li = document.createElement("li");
        li.classList.add("answer-option");
        li.textContent = option;
        li.addEventListener("click", () => handleAnswer(li, index));
        answerOptions.appendChild(li);
    });
    
    // Start timer after UI is updated
    startTimer();
}

const startQuiz = () => {
    configContainer.style.display = "none";
    quizContainer.style.display = "block";
    quizCategory = configContainer.querySelector(".category-option.active").textContent;
    numberOfQuestions = parseInt(configContainer.querySelector(".question-option.active").textContent);
    
    renderQuestion();
}

const resetQuiz = () => {
    resetTimer();
    correctAnswerCount = 0;
    questionsIndexHistory.length = 0;
    configContainer.style.display = "block";
    resultContainer.style.display = "none";
}

// Initialize the quiz application
document.addEventListener('DOMContentLoaded', () => {
    // Set initial display state
    configContainer.style.display = "block";
    quizContainer.style.display = "none";
    resultContainer.style.display = "none";
    
    // Add event listeners for category and question options
    document.querySelectorAll(".category-option, .question-option").forEach(option => {
        option.addEventListener("click", () => {
            const activeElement = option.parentNode.querySelector(".active");
            if (activeElement) {
                activeElement.classList.remove("active");
            }
            option.classList.add("active");
        });
    });
    
    // Add event listeners for buttons
    nextQuestionBtn.addEventListener("click", renderQuestion);
    document.querySelector(".try-agin-btn").addEventListener("click", resetQuiz);
    document.querySelector(".start-quiz-btn").addEventListener("click", startQuiz);
});