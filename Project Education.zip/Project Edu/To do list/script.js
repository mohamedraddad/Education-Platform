function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');
    
    if (taskInput.value.trim() === '') {
        alert('Please enter a task!');
        return;
    }

    const taskItem = document.createElement('li');
    taskItem.className = 'task-item';
    const taskText = document.createElement('span');
    taskText.className = 'task-text';
    taskText.textContent = taskInput.value;
    
    const completeBtn = document.createElement('button');
    completeBtn.className = 'complete-btn';
    completeBtn.textContent = 'Complete';
    completeBtn.onclick = function() {
        taskText.classList.toggle('completed');
        completeBtn.textContent = taskText.classList.contains('completed') ? 'Undo' : 'Complete';
    };
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = 'Delete';
    deleteBtn.onclick = function() {
        taskList.removeChild(taskItem);
    };
    
    taskItem.appendChild(taskText);
    taskItem.appendChild(completeBtn);
    taskItem.appendChild(deleteBtn);
    
    taskList.appendChild(taskItem);
    
    taskInput.value = '';
}

document.getElementById('taskInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        addTask();
    }
}); 