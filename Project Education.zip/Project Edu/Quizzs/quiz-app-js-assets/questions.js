// Array of questions grouped by category (25 questions each)

const questions = [
  {
    category: "Programming and Web Development",
    questions: [
      {
        question: "What does HTML stand for?",
        options: ["Hyper Text Pre Processor", "Hyper Text Markup Language", "Hyper Text Multiple Language", "Hyper Tool Multi Language"],
        correctAnswer: 1,
      },
      {
        question: "Which HTML tag is used to define an internal stylesheet?",
        options: ["<script>", "<style>", "<link>", "<css>"],
        correctAnswer: 1,
      },
      {
        question: "Which CSS property changes the text color?",
        options: ["font-color", "text-color", "color", "text-style"],
        correctAnswer: 2,
      },
      {
        question: "What does CSS stand for?",
        options: ["Cascading Style Sheets", "Colorful Style Sheets", "Computer Style Sheets", "Creative Style Sheets"],
        correctAnswer: 0,
      },
      {
        question: "In JavaScript, how do you create a function?",
        options: ["create function myFunction()", "def function myFunction()", "func myFunction()", "function myFunction()"],
        correctAnswer: 3,
      },
      {
        question: "What does the 'typeof' operator do in JavaScript?",
        options: ["Checks the type of a variable", "Declares a variable", "Assigns a value to a variable", "Converts a variable to another type"],
        correctAnswer: 0,
      },
      {
        question: "What does margin: 0 auto; do in CSS",
        options: ["Removes all margins", "Centers an element horizontally", "Sets top and bottom margins to zero", "Adds automatic margins"],
        correctAnswer: 1,
      },
      {
        question: "What is Flexbox used for?",
        options: ["Creating animations","Building responsive layouts", "Storing data", "Writing JavaScript functions"],
        correctAnswer: 1,
      },
      {
        question: "Which language is used for Android development?",
        options: ["Python", "Java", "JavaScript", "C++"],
        correctAnswer: 1,
      },
      {
        question: "What is the purpose of the 'forEach()' method in JavaScript?",
        options: ["Removes duplicate elements from an array", "Filters elements in an array", "Sorts an array", "Iterates through each element in an array"],
        correctAnswer: 3,
      },
      {
        question: "What does the 'return' keyword do in a function?",
        options: ["Ends the function and returns a value", "Continues the function", "Exits the function without value", "Ends the program execution"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is NOT a semantic HTML element?",
        options: ["<header>", "<footer>", "<div>", "<article>"],
        correctAnswer: 2,
      },
      {
        question: "What is the primary purpose of a 'for' loop in programming?",
        options: ["Repeat code for a specified number of times", "Repeat code until a condition is true", "Define a function", "Evaluate conditions in the loop"],
        correctAnswer: 0,
      },
      {
        question: "Which data structure is ideal for LIFO (Last In First Out)?",
        options: ["Queue", "Stack", "Linked list", "Array"],
        correctAnswer: 1,
      },
      {
        question: "Which command is used in Git to store changes in the repository?",
        options: ["git commit", "git push", "git pull", "git add"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'map()' function do in JavaScript?",
        options: ["Sorts an array", "Filters out items", "Creates a new array", "Modifies the original array"],
        correctAnswer: 2,
      },
      {
        question: "What is an IDE?",
        options: ["An Integrated Development Environment", "A function for code execution", "An interpreter", "An input method for writing code"],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is a feature of object-oriented programming?",
        options: ["Encapsulation", "Modularity", "Recursion", "Memory Management"],
        correctAnswer: 0,
      },
      {
        question: "What does SQL stand for?",
        options: ["Simple Question Language", "Systematic Query Language", "Standard Question Language", "Structured Query Language"],
        correctAnswer: 3,
      },
      {
        question: "Which of these is an example of a non-relational database?",
        options: ["MongoDB", "MySQL", "PostgreSQL", "Oracle"],
        correctAnswer: 0,
      },
      {
        question: "How do you write comment in CSS?",
        options: ["// This is a comment", "/* This is a comment */", "# This is a comment", "<!-- This is a comment -->"],
        correctAnswer: 1,
      },
      {
        question: "Which of the following algorithms is used to sort an array by comparing elements?",
        options: ["Bubble sort", "Insertion sort", "Quick sort", "Merge sort"],
        correctAnswer: 0,
      },
      {
        question: "What does the 'finally' block in Java do?",
        options: ["Handles all exceptions", "Attempts to handle runtime exceptions", "Executes code after try-catch", "Defines execution start point"],
        correctAnswer: 2,
      },
      {
        question: "Which data structure is best for searching elements quickly?",
        options: ["Binary search tree", "Array", "Linked list", "Queue"],
        correctAnswer: 0,
      },
      {
        question: "What is the correct syntax for a JavaScript if statement?",
        options: ["if (condition) {}", "if condition {}", "if {} else", "if {condition}"],
        correctAnswer: 0,
      },
    ],
  },
  {
    category: "Data Science",
    questions: [
      {
        question: "What is the primary difference between AI and Machine Learning?",
        options: [
          "AI requires programming, ML doesn't",
          "ML is a subset of AI focused on learning from data",
          "AI only works with big data",
          "ML doesn't use algorithms"
        ],
        correctAnswer: 1
      },
      {
        question: "Which Python library is essential for numerical computing in Data Science?",
        options: ["Pandas", "NumPy", "Matplotlib", "Scikit-learn"],
        correctAnswer: 1
      },
      {
        question: "What does 'overfitting' mean in ML?",
        options: [
          "Model performs well on training data but poorly on new data",
          "Model learns too slowly",
          "Model ignores important features",
          "Training process takes too long"
        ],
        correctAnswer: 0
      },
      {
        question: "Which neural network architecture is best for image recognition?",
        options: ["RNN", "CNN", "GAN", "MLP"],
        correctAnswer: 1
      },
      {
        question: "What is the purpose of a confusion matrix?",
        options: [
          "Visualize neural network architecture",
          "Evaluate classification model performance",
          "Clean messy datasets",
          "Reduce feature dimensions"
        ],
        correctAnswer: 1
      },
      {
        question: "Which technique is NOT used for dimensionality reduction?",
        options: ["PCA", "t-SNE", "LDA", "SVM"],
        correctAnswer: 3
      },
      {
        question: "What does 'GPT' stand for in AI models?",
        options: [
          "General Purpose Transformer",
          "Generative Pre-trained Transformer",
          "Graphical Processing Technique",
          "Guided Parameter Tuning"
        ],
        correctAnswer: 1
      },
      {
        question: "Which evaluation metric is most important for imbalanced classification?",
        options: ["Accuracy", "F1 Score", "R-squared", "MSE"],
        correctAnswer: 1
      },
      {
        question: "What is the main advantage of Random Forest over Decision Trees?",
        options: [
          "Faster training time",
          "Reduced overfitting through ensemble learning",
          "Works only with categorical data",
          "Doesn't require hyperparameter tuning"
        ],
        correctAnswer: 1
      },
      {
        question: "Which is NOT a type of machine learning?",
        options: ["Supervised", "Unsupervised", "Reinforcement", "Synthetic"],
        correctAnswer: 3
      },
      {
        question: "What does 'ReLU' stand for in neural networks?",
        options: [
          "Rectified Linear Unit",
          "Recursive Learning Unit",
          "Randomized Linear Update",
          "Regression Learning Unit"
        ],
        correctAnswer: 0
      },
      {
        question: "Which algorithm would you use for recommendation systems?",
        options: ["KNN", "Collaborative Filtering", "K-Means", "SVM"],
        correctAnswer: 1
      },
      {
        question: "What is the purpose of dropout in neural networks?",
        options: [
          "Increase model complexity",
          "Regularization to prevent overfitting",
          "Speed up backpropagation",
          "Reduce input dimensions"
        ],
        correctAnswer: 1
      },
      {
        question: "Which is NOT a common data preprocessing step?",
        options: ["Normalization", "One-hot encoding", "Feature engineering", "Model deployment"],
        correctAnswer: 3
      },
      {
        question: "What does 'BERT' stand for in NLP?",
        options: [
          "Bidirectional Encoder Representations from Transformers",
          "Basic Encoding of Recurrent Text",
          "Binary Entity Recognition Technology",
          "Best Embedding for Related Text"
        ],
        correctAnswer: 0
      },
      {
        question: "Which visualization is best for showing correlations?",
        options: ["Bar chart", "Heatmap", "Pie chart", "Line graph"],
        correctAnswer: 1
      },
      {
        question: "What is the main challenge in time series forecasting?",
        options: [
          "Handling temporal dependencies",
          "Dealing with categorical data",
          "Feature scaling",
          "Image recognition"
        ],
        correctAnswer: 0
      },
      {
        question: "Which is NOT a clustering algorithm?",
        options: ["K-Means", "DBSCAN", "Hierarchical", "Linear Regression"],
        correctAnswer: 3
      },
      {
        question: "What is 'transfer learning' in deep learning?",
        options: [
          "Training from scratch",
          "Reusing pre-trained models on new tasks",
          "Converting models to different programming languages",
          "Transferring data between servers"
        ],
        correctAnswer: 1
      },
      {
        question: "Which metric would you use for regression problems?",
        options: ["Accuracy", "Precision", "Mean Squared Error", "F1 Score"],
        correctAnswer: 2
      },
      {
        question: "What is the 'curse of dimensionality'?",
        options: [
          "Models perform better with more features",
          "Data becomes sparse as dimensions increase",
          "Training time decreases with more features",
          "Algorithms become more accurate"
        ],
        correctAnswer: 1
      },
      {
        question: "Which activation function is used for binary classification output?",
        options: ["ReLU", "Sigmoid", "Tanh", "Leaky ReLU"],
        correctAnswer: 1
      },
      {
        question: "What does 'XGBoost' stand for?",
        options: [
          "Extreme Gradient Boosting",
          "XML Gradient Boosting",
          "Xeno Genetic Boosting",
          "Experimental Graph Boosting"
        ],
        correctAnswer: 0
      },
      {
        question: "Which is NOT a use case for unsupervised learning?",
        options: ["Customer segmentation", "Anomaly detection", "Image classification", "Market basket analysis"],
        correctAnswer: 2
      },
      {
        question: "What is the key advantage of transformers in NLP?",
        options: [
          "Processing sequences in parallel",
          "Requiring less training data",
          "Working only with small texts",
          "Not needing attention mechanisms"
        ],
        correctAnswer: 0
      }
    ]
  },
  {
    category: "SQL and Databases",
    questions: [
      {
        question: "What does DBMS stand for?",
        options: [
          "Database Management System",
          "Data Base Management Software",
          "Database Master System",
          "Data Backup Management System"
        ],
        correctAnswer: 0
      },
      {
        question: "Which SQL command retrieves data from a database?",
        options: [
          "GET",
          "SELECT",
          "FETCH",
          "RETRIEVE"
        ],
        correctAnswer: 1
      },
      {
        question: "Which of the following is a type of JOIN in SQL?",
        options: [
          "INNER JOIN",
          "LEFT JOIN",
          "CROSS JOIN",
          "All of the above"
        ],
        correctAnswer: 3
      },
      {
        question: "What is the primary purpose of normalization?",
        options: [
          "To reduce data redundancy",
          "To speed up backups",
          "To encrypt sensitive data",
          "To compress database size"
        ],
        correctAnswer: 0
      },
      {
        question: "Which SQL clause filters groups after aggregation?",
        options: [
          "WHERE",
          "GROUP BY",
          "HAVING",
          "ORDER BY"
        ],
        correctAnswer: 2
      },
      {
        question: "What is a foreign key?",
        options: [
          "A key that uniquely identifies a row",
          "A key linking two tables via a reference",
          "A key used for encryption",
          "A temporary key"
        ],
        correctAnswer: 1
      },
      {
        question: "Which command creates a new table in SQL?",
        options: [
          "CREATE TABLE",
          "DEFINE TABLE",
          "NEW TABLE",
          "ADD TABLE"
        ],
        correctAnswer: 0
      },
      {
        question: "What does ACID stand for in databases?",
        options: [
          "Atomicity, Consistency, Isolation, Durability",
          "Accuracy, Consistency, Integrity, Durability",
          "Automation, Concurrency, Indexing, Durability",
          "None of the above"
        ],
        correctAnswer: 0
      },
      {
        question: "Which SQL function counts the number of rows?",
        options: [
          "TOTAL()",
          "SUM()",
          "COUNT()",
          "AGGREGATE()"
        ],
        correctAnswer: 2
      },
      {
        question: "What is a SQL view?",
        options: [
          "A physical copy of a table",
          "A virtual table based on a query",
          "A backup of a database",
          "A graphical representation of data"
        ],
        correctAnswer: 1
      },
      {
        question: "Which SQL statement is used to update data in a database?",
        options: [
          "SAVE",
          "MODIFY",
          "UPDATE",
          "EDIT"
        ],
        correctAnswer: 2
      },
      {
        question: "What is an SQL injection attack?",
        options: [
          "A hardware failure affecting database servers",
          "Inserting malicious code via input fields",
          "A method to optimize database performance",
          "Adding new tables to a database"
        ],
        correctAnswer: 1
      },
      {
        question: "Which of these is NOT a type of database?",
        options: [
          "Relational",
          "Document-oriented",
          "Algorithmic",
          "Graph"
        ],
        correctAnswer: 2
      },
      {
        question: "What is the purpose of an index in a database?",
        options: [
          "To enforce data integrity",
          "To speed up data retrieval",
          "To encrypt sensitive data",
          "To format query outputs"
        ],
        correctAnswer: 1
      },
      {
        question: "Which SQL command removes a table from a database?",
        options: [
          "DELETE TABLE",
          "REMOVE TABLE",
          "DROP TABLE",
          "ERASE TABLE"
        ],
        correctAnswer: 2
      },
      {
        question: "What is a stored procedure?",
        options: [
          "A way to store database backups",
          "A saved SQL code that can be reused",
          "A method to encrypt database columns",
          "A file containing database schema"
        ],
        correctAnswer: 1
      },
      {
        question: "Which of these is a NoSQL database?",
        options: [
          "MySQL",
          "Oracle",
          "MongoDB",
          "PostgreSQL"
        ],
        correctAnswer: 2
      },
      {
        question: "What does SQL's ORDER BY clause do?",
        options: [
          "Filters rows before grouping",
          "Sorts the result set",
          "Joins multiple tables",
          "Limits the number of rows returned"
        ],
        correctAnswer: 1
      },
      {
        question: "Which is NOT a valid SQL aggregate function?",
        options: [
          "AVG()",
          "COUNT()",
          "MEAN()",
          "MAX()"
        ],
        correctAnswer: 2
      },
      {
        question: "What is database sharding?",
        options: [
          "Deleting unnecessary data",
          "Splitting a database across multiple servers",
          "Combining multiple databases",
          "Encrypting database content"
        ],
        correctAnswer: 1
      },
      {
        question: "Which statement is used to combine rows from two or more tables?",
        options: [
          "COMBINE",
          "MERGE",
          "JOIN",
          "UNION"
        ],
        correctAnswer: 2
      },
      {
        question: "What is a primary key?",
        options: [
          "The first column in a table",
          "A unique identifier for each row",
          "The password to access a database",
          "The main database server"
        ],
        correctAnswer: 1
      },
      {
        question: "What does the DISTINCT keyword do in SQL?",
        options: [
          "Sorts the result set",
          "Removes duplicate rows",
          "Formats query output",
          "Filters specific columns"
        ],
        correctAnswer: 1
      },
      {
        question: "Which SQL constraint ensures a column cannot have NULL values?",
        options: [
          "UNIQUE",
          "PRIMARY KEY",
          "NOT NULL",
          "CHECK"
        ],
        correctAnswer: 2
      },
      {
        question: "What is database normalization?",
        options: [
          "Converting a database to a specific format",
          "Organizing data to reduce redundancy",
          "Optimizing database performance",
          "Backing up database content"
        ],
        correctAnswer: 1
      }
    ]
  }
];